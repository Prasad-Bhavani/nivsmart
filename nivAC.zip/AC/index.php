﻿<script type="text/javascript">
window.location.href='../index.php';
</script>